
### How to run the job
Run the following command to deploy the job in Flink:
```
make homework_job
```

or

```
docker compose exec jobmanager ./bin/flink run -py /opt/src/job/homework_job.py --pyFiles /opt/src -d
```

### Business Questions:
- **What is the average number of web events of a session from a user on Tech Creator?**
```
SELECT 
AVG(num_hits) AS avg_hits_per_session 
FROM processed_events_aggregated 
WHERE host LIKE '%techcreator.io';
```
**- Compare results between different hosts (zachwilson.techcreator.io, zachwilson.tech, lulu.techcreator.io)**
```
SELECT 
	host, 
	AVG(num_hits) AS avg_hits_per_session
FROM processed_events_aggregated
GROUP BY host
HAVING host IN ('zachwilson.techcreator.io', 'zachwilson.tech', 'lulu.techcreator.io')
```