Link to the exploratory dashboaard:

https://public.tableau.com/app/profile/alvaro.vilaplana.garcia/viz/homework-1-alvaro-vilaplana/Exploratory?publish=yes

There are 4 panels:
- Top Players with > 1000 medals
- Top Players with > 3000 kills
- Top Players with > 500 wins
- Playlist with > 1000 games


https://public.tableau.com/app/profile/alvaro.vilaplana.garcia/viz/homework-2-alvaro-vilaplana/Executive?publish=yes

There are 3 panels:
- Number of matches per date
- Players with lowest average kills
- Top Players with highest average kills
